You need 4 input parameters:
1. uri - The SQL Endpoint URI (and you can access it)
2. token - Personal Access Token (and you have READ permission the TPC-DS database specified)
3. concurrency - How many threads/streams of TPC-DS queries are running in parallel. 10 is the recommended number.
4. schema - The database/schema that contains the TPC-DS dataset

Syntax:
./run.sh "<URI>" <token> <concurrency> <schema>

Example:
./run.sh "jdbc:databricks://e2-demo-west.cloud.databricks.com:443/default;transportMode=http;ssl=1;AuthMech=3;httpPath=/sql/1.0/endpoints/29c44a462d0d7d82;"  dapi532c884ef8e5215916219f334dd49358 1 tpcds_sf1_delta_nopartitions 

