#! /bin/sh
BASEDIR=$(dirname $0)

java --add-opens=java.base/java.nio=ALL-UNNAMED -cp $BASEDIR/ThroughputTest-1.0-SNAPSHOT-jar-with-dependencies.jar com.Databricks.ThroughputTest \
$1 $2 $3 $4 $BASEDIR

echo "${BASEDIR}"